#Here we are will refresh the credentials everytime
subscription_id = 'subscription_id'
tenant_id = "tenant_id"
client_id = "client_id"
client_secret = "client_secret"
password= "password_"